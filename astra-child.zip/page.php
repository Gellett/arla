<?php
/*
Template Name: PageTemplate
*/
?>


----> Skriv html her <----


<style>
<?php include 'style.css'; ?>
</style>